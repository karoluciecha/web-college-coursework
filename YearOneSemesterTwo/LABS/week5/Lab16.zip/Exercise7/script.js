function changeColor() {
    document.getElementById("myText").style.color = "red";
}
function changeSize() {
    document.getElementById("myText").style.fontSize = "3em";
}
function changeFont() {
    document.getElementById("myText").style.fontFamily = "Calibri";
}
