function changeH1() {
    document.getElementById("myHeading1").innerHTML = "Hello " + prompt("Please enter your name:") + ".";
}