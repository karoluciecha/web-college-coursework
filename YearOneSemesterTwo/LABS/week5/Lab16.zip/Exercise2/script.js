function changeH1() {
    document.getElementById("myHeading1").innerHTML = "Heading 1 changed!";
}
function changeH2() {
    document.getElementById("myHeading2").innerHTML = "Heading 2 changed!";
}
function changeH3() {
    document.getElementById("myHeading3").innerHTML = "Heading 3 changed!";
}