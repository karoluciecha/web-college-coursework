function greeting() {
    document.getElementById("myHeading1").innerHTML = "Hello " + document.getElementById("intext").value + "!";
}