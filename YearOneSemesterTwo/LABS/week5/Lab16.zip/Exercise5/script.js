function add() {
    document.getElementById("myHeading1").innerHTML = Number(document.getElementById("innum1").value) + Number(document.getElementById("innum2").value);
}