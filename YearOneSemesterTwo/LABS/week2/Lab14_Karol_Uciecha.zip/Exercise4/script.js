let fname = prompt("What is your first name?");
let color = prompt("What is your favourite color?");
let weekday = prompt("What day is it?");
let lnumber = prompt("What is your lucky number?");

document.write("Welcome " + fname + "!<br>");
document.write("First name: " + fname + "<br>")
document.write("Favourite color: " + color + "<br>")
document.write("Curent day of week: " + weekday + "<br>")
document.write("Lucky number: " + lnumber + "<br>")