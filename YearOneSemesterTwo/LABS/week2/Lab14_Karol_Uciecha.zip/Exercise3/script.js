let username = prompt("What is your name?");
document.write(username);