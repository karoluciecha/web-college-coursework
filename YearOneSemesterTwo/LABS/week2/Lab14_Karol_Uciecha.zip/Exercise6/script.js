let len = prompt("Enter length:");
let wdt = prompt("Enter width:");
let units = prompt("Unit of measurement:")

document.write("Area of Rectangle: " + (Number(len) * Number(wdt)) + " " + units + "<br>");