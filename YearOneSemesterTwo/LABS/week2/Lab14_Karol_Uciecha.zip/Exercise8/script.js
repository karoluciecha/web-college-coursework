let num1 = prompt("Enter a number:");

if (num1 < 0) {
    document.write("Entered number (" + num1 + ") is negative.");
} else if (num1 > 0) {
    document.write("Entered number (" + num1 + ") is positive.");
} else {
    document.write("Entered number (" + num1 + ") is equal to 0.");
}




