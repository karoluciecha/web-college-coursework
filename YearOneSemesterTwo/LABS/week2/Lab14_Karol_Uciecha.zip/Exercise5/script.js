let num1 = prompt("Enter first number:");
let num2 = prompt("Enter second number:");

document.write("Sum: " + (Number(num1) + Number(num2)) + "<br>");
document.write("Difference: " + (num1 - num2) + "<br>");
document.write("Product: " + (num1 * num2) + "<br>");
document.write("Quotient: " + (num1 / num2) + "<br>");
document.write("Modulo: " + (num1 % num2) + "<br>");
document.write("Reversed modulo: " + (num2 % num1) + "<br>");