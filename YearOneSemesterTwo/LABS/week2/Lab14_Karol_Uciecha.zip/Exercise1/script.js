alert("Hello World!");
document.write("Welcome!");